import java.util.Scanner;
import java.util.ArrayList;

class Record{

   ArrayList<String> record;

   // Set the initial value for number of columns. //
   int numOfcols = 0;
   int index;

   void fillRecord(){

      System.out.print("enter the content:\n");
      Scanner scanner = new Scanner(System.in);

      while(!scanner.hasNext("/")){
         record.add(scanner.next());
         numOfcols++;
      }

   }

   void printRecord(){

     for(int i = 0; i < record.size(); i++) {
        System.out.print(record.get(i)+" ");
     }

   }

   public static void main(String[] args) {

      Record b = new Record();
      b.record = new ArrayList<String>();

      b.fillRecord();
      b.printRecord();

   }

}

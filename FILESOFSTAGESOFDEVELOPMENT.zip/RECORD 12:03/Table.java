import java.util.Scanner;
import java.util.ArrayList;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

class Table{

   ArrayList<Record> table;
   ArrayList<String> fieldnames;

   int numOfcols = 0;
   int numOfrows = 0;

   void setFieldnames(){

      System.out.print("enter field names:\n");
      Scanner scanner = new Scanner(System.in);

      while(!scanner.hasNext("/")){
        fieldnames.add(scanner.next());
        numOfcols++;
      }
      scanner.close();

   }

   void printFieldnames(){

      for(int i = 0; i < fieldnames.size(); i++) {
         System.out.print(fieldnames.get(i)+" ");
      }

   }

   void addRecord(Record r){

      table.add(r);
      numOfrows++;
      r.index = numOfrows;

   }
/*
   void deleteRecord(){

   }

   void printTable(){

   }
*/
   public static void main(String[] args) {

      Table b = new Table();
      b.fieldnames = new ArrayList<String>();
      b.table = new ArrayList<Record>();
      b.setFieldnames();
      b.printFieldnames();

      Record c = new Record();/*
      c.record = new ArrayList<String>();
      c.fillRecord();
      c.printRecord();*/

      b.addRecord(c);

   }

}

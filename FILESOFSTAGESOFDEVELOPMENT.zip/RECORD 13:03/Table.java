import java.util.Scanner;
import java.util.ArrayList;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

class Table{

   ArrayList<Record> table;
   ArrayList<String> fieldnames;
   ArrayList<Integer> columnwidth;

   String table_name;

   int numOfcols = 0;
   int numOfrows = 0;

   void setFieldnames(){

      System.out.print("enter field names:\n");
      Scanner scanner = new Scanner(System.in);

      while(!scanner.hasNext("/")){
        fieldnames.add(scanner.next());
        numOfcols++;
      }

   }

   void printFieldnames(){

      for(int i = 0; i < fieldnames.size(); i++) {
         System.out.print(fieldnames.get(i)+" ");
      }
      System.out.print("\n");

   }

   void insertRecord(Record r){

      table.add(r);
      numOfrows++;
      r.index = numOfrows;

   }
/*
   void deleteRecord(){

   }
*/
   void printTable(){

      printFieldnames();

      for (int j = 0; j < table.size(); j++) {
         for(int i = 0; i < ((table.get(j)).record).size(); i++) {
            System.out.print(((table.get(j)).record).get(i)+" ");
         }
      }

   }

   void get_tablename(){

      System.out.print("enter the file names:\n");
      java.util.Scanner a = new java.util.Scanner(System.in);
      table_name = a.next();

   }

   void get_columnwidth(){

      for(int k = 0; k < fieldnames.size(); k++){ 
         columnwidth.add((fieldnames.get(k)).length());
      }

      for(int j = 0; j < fieldnames.size(); j++){
         for(int i = 0; i < ((table.get(j)).record).size(); i++) {
            if(columnwidth.get(j) < (((table.get(j)).record).get(i)).length()){
               columnwidth.set(j, (((table.get(j)).record).get(i)).length());
            }
         }
      }

   }

   public static void main(String[] args) {

      Table b = new Table();
      b.fieldnames = new ArrayList<String>();
      b.table = new ArrayList<Record>();
      b.setFieldnames();
      b.printFieldnames();

      Record c = new Record();
      /*
      c.record = new ArrayList<String>();
      c.fillRecord();
      c.printRecord();*/

      b.insertRecord(c);
      b.get_columnwidth();
      b.printTable();

   }

}

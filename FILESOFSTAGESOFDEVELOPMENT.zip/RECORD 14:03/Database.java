import java.util.Scanner;
import java.util.ArrayList;


class Table{

   ArrayList<Table> database;

   void addTable(Table t){

      database.add(t);

   }



}

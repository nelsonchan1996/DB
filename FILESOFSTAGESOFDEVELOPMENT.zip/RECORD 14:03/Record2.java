import java.util.*;

class Record{


   public ArrayList<StringBuilder> record;

   public int numOfcols;

   public void fillRecord(){

      System.out.print("enter the content:\n");
      java.util.Scanner a = new java.util.Scanner(System.in);
      int current = 0;

      while(current<numOfcols){
         record[current] = a.next();
         current++;
      }

   }

   public void printRecord(){

      int a;

      System.out.print("the content recorded:\n");

      for(a = 0; a < numOfcols; a++){
         System.out.print(record[a]);
         System.out.print(" ");
      }

      System.out.print("\n");

   }

   public static void main(String[] args) {

      Record a = new Record();

      a.record = new ArrayList<StringBuilder>();
      a.fillRecord();
      a.printRecord();

   }

}

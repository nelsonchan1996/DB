import java.util.Scanner;
import java.util.ArrayList;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

class Table{

   ArrayList<Record> table;
   ArrayList<String> fieldnames;

   int[] column_width;
   String table_name;
   String primary_key;

   int numOfcols = 0;
   int numOfrows = 0;

   void setFieldnames(){

      System.out.print("enter field names:\n");
      Scanner scanner = new Scanner(System.in);

      while(!scanner.hasNext("/")){
        fieldnames.add(scanner.next());
        numOfcols++;
      }

   }

   void printFieldnames(){

      for(int i = 0; i < fieldnames.size(); i++) {
         System.out.print(fieldnames.get(i));
         if((fieldnames.get(i)).equals(primary_key)){
            System.out.print("*");
         }
         System.out.print(" ");
      }
      System.out.print("\n");

   }

   void insertRecord(Record r){

      table.add(r);
      numOfrows++;
      r.index = numOfrows;

   }
/*
   void deleteRecord(){

   }
*/
   void printTable(){

      printFieldnames();

      for (int j = 0; j < table.size(); j++) {
         for(int i = 0; i < ((table.get(j)).record).size(); i++) {
            System.out.print(((table.get(j)).record).get(i)+" ");
         }
      }

      System.out.print("\n");

   }

   void get_tablename(){

      System.out.print("enter the file names:\n");
      java.util.Scanner a = new java.util.Scanner(System.in);
      table_name = a.next();

   }

   void get_columnwidth(){

      column_width = new int [fieldnames.size()+1];

      for(int k = 0; k < fieldnames.size(); k++){
        /*
         columnwidth.add((fieldnames.get(k)).length());
         */
         int temp = (fieldnames.get(k)).length();
         column_width[k] = temp;
         System.out.print(k+":"+column_width[k]+"\n");

      }

   /*
         for(int i = 0; i <= ((table.get(j)).record).size(); i++) {
            for(int j = 0; j < fieldnames.size(); j++){

            String tempString = ((table.get(i)).record).get(j);
            if(column_width[j] < tempString.length()){
               column_width[j] = (((table.get(i)).record).get(j)).length();
            }
         }
      }*/

   }

   void writing() {

       try {
           //Whatever the file path is.
           File statText = new File(table_name+".txt");
           FileOutputStream is = new FileOutputStream(statText);
           OutputStreamWriter osw = new OutputStreamWriter(is);
           Writer w = new BufferedWriter(osw);

           for(int i = 0; i < fieldnames.size(); i++) {
              w.write(fieldnames.get(i));
              if((fieldnames.get(i)).equals(primary_key)){
                 w.write("*");
              }
              w.write(" ");
           }
           w.write("\n");

           for(int j = 0; j < table.size(); j ++){
              for(int i = 0; i < ((table.get(j)).record).size(); i++){
                 w.write(((table.get(j)).record).get(i)+" ");
              }
              w.write("\n");
           }
           w.close();

       } catch (IOException e) {
           System.err.println("Problem writing to the file statsTest.txt");
       }

   }


   void get_key(){

      System.out.print("which filed is primary key:\n");

      java.util.Scanner a = new java.util.Scanner(System.in);
      primary_key = a.next();

      System.out.print(primary_key+"\n");

   }

   public static void main(String[] args) {

      Table b = new Table();

      b.fieldnames = new ArrayList<String>();
      b.table = new ArrayList<Record>();

      b.get_tablename();
      b.setFieldnames();
      b.printFieldnames();
      b.get_key();

      Record c = new Record();

      /*
      c.record = new ArrayList<String>();
      c.fillRecord();
      c.printRecord();
      */

      b.insertRecord(c);
      b.get_columnwidth();
      b.printTable();
      b.writing();

   }

}

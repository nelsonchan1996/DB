import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

class Table {

   final int INTIAL_MAXROWS = 5;
   final int INITIAL_MAXCOLS = 5;

   public ArrayList<Record> table = new ArrayList<Record>();

   public int[] column_width = new int [INITIAL_MAXCOLS];
   public String table_name;

   public int numOfrows, numOfcols;
   public int current_row = 0;

 }

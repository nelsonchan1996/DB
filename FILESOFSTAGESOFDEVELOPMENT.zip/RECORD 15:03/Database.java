import java.util.Scanner;
import java.util.ArrayList;

class Database{

   // An arraylist that stores each record of the table
   ArrayList<Table> database;
   // Name of database
   String database_name;

   // Set the database name
   void setDatabaseName(){

   }

   // Add a table
   void addTable(Table t){
      database.add(t);
   }

   // Remove a table from database
   void dropTable(){

   }

   // Print the heading
   void printHeading(){

      int sum = 0;
      for(int k = 0; k < features.size(); k++){
         sum = sum + column_width[k];
      }
      int headinglength = sum + (features.size()+1);
      for(int i = 0; i < headinglength; i++){
         System.out.print("-");
      }
         System.out.print("\n");
      }

   // Print the padding space
   void printSpace(int n){

      for(int i = 0; i < n; i++){
         System.out.print(" ");
      }

   }

   // Print column bar
   void printColumn(){

      System.out.print("|");

   }

}

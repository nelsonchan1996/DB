import java.util.Scanner;
import java.util.ArrayList;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.io.FileReader;
import java.io.BufferedReader;

class Table{

   // An arraylist that stores each record of the table
   ArrayList<Record> table;
   // An arraylist that stores each field names of the table
   ArrayList<String> features;
   // An arraylist that stores composite primary key
   ArrayList<String> composite_primary_key;
   // An array that stores the maxwidth of each column
   int[] column_width;
   // A 2-D array that stores the content scanned from a readable file
   String[][] file_content;

   // the name of the table
   String table_name;
   // the primary key of the table
   String primary_key;
   // the foreign key of the table
   String foreign_key;
   // the number of features
   int num_of_features;
   // primary key index
   int primary_key_index;

   // 2-space padding for printing
   final int padding = 2;

   // CONSTRUCTOR
   // Trivial Constructor
   Table(){

      this.table = null;
      this.features = null;
      this.column_width = null;
      this.table_name = null;
      this.primary_key = null;
      this.foreign_key = null;

   }

   // Constructor that initialise the table
   Table(String table_name){

      this.table = new ArrayList<Record>();
      this.table_name = table_name;

      this.features = new ArrayList<String>();
      this.setFeatures();

   }

   // RECORDS
   // Insert a record to the table arrayList
   void insertRecord(Record r){

      if(checkPrimarykeyConstraint(r)==true){
         table.add(r);
         System.out.println("Record inserted.");
      }
      else{
         System.out.println("Error: Record insertion failed."+
"The record violates the primary key constraint.");
      }

   }

   // FEATURES
   // Set the features(field names) and the number of features
   void setFeatures(){

      System.out.println("enter field names:");
      Scanner scanner = new Scanner(System.in);

      while(!scanner.hasNext("/")){
         features.add(scanner.next());
      }

      this.num_of_features = features.size();

   }

   // KEY
   // Set the primary key
   void setPrimarykey(){

      System.out.println("enter primary key:");
      Scanner scanner = new Scanner(System.in);
      int a = 0;
      String temp = scanner.next();

      for(int i = 0; i < features.size(); i++){
         if(features.get(i).equals(temp)){
            a++;
         }
      }

      if(a == 1){
         if(checkPrimarykey(temp)==true){
            this.primary_key = temp;
            System.out.println("The primary key is "+temp);
         }
         else{
           System.out.println("Error: Primary key setting failed. "
  +"Repeated values not allowed. Please choose another feature.");
         }
      }
      else{
         System.out.println("Error: Primary key setting failed. "
+"Please enter a correct field name.");
      }

   }

   // Check whether the primary key set fulfills the requirement
   Boolean checkPrimarykey(String feature){

      int ind = -1;

      for(int i = 0; i < features.size(); i++){
         if(features.get(i).equals(feature)){
            ind = i;
         }
      }

      if(ind == -1){return false;}

      for(int j = 0; j < table.size(); j++) {
         for(int k = j+1; k < table.size(); k++){
            if(table.get(j).record.get(ind).equals(table.get(k).record.get(ind))){
               return false;
            }
         }
      }
      primary_key_index = ind;
      return true;

   }

   // Check whether the record to be inserted fulfills the primary constraint
   Boolean checkPrimarykeyConstraint(Record r){


      for(int k = 0; k < table.size(); k++){
         if(table.get(k).record.get(primary_key_index).equals(r.record.get(primary_key_index))){
            return false;
         }
      }

      return true;

   }

   // PRINTING
   // get the maximum width of each column
   void getColumnwidth(){

      // initialise the array
      this.column_width = new int [features.size()];
      // set the length of each feature as the initial width
      for(int k = 0; k < features.size(); k++){
         int temp = (features.get(k)).length();
         column_width[k] = temp;
      }

      for(int j = 0; j < table.size(); j++) {
         for(int i = 0; i < table.get(j).record.size(); i++) {
            if(column_width[i] < table.get(j).record.get(i).toString().length()){
               column_width[i] = table.get(j).record.get(i).toString().length();
            }
         }
      }

      // add padding to the column width
      for(int k = 0; k < features.size(); k++){
         column_width[k] = column_width[k]+padding*2;
      }

   }

   // Print the heading
   void printHeading(){

      int sum = 0;
      for(int k = 0; k < features.size(); k++){
         sum = sum + column_width[k];
      }
      int headinglength = sum + (features.size()+1);
      for(int i = 0; i < headinglength; i++){
         System.out.print("-");
      }
      System.out.print("\n");

   }

   // Print the padding space
   void printSpace(int n){

      for(int i = 0; i < n; i++){
         System.out.print(" ");
      }

   }

   // Print column bar
   void printColumn(){

      System.out.print("|");

   }

   // Print the features(field names/attributes)
   void printFeatures(){

      int left_paddinglength;
      int right_paddinglength;

      printHeading();
      printColumn();

      for(int i = 0; i < features.size(); i++) {

         if((column_width[i]-features.get(i).toString().length())%2 == 0){
            left_paddinglength = (column_width[i] - features.get(i).toString().length())/2;
            right_paddinglength = column_width[i] - features.get(i).toString().length() - left_paddinglength;
         }
         else{
            left_paddinglength = (column_width[i] - features.get(i).toString().length() + 1)/2;
            right_paddinglength = column_width[i] - features.get(i).toString().length() - left_paddinglength;
         }

         printSpace(left_paddinglength);
         System.out.print(features.get(i));
         printSpace(right_paddinglength);
         printColumn();

      }
      System.out.print("\n");
      printHeading();

   }

   // Print record
   void printRecord(){

      int left_paddinglength;
      int right_paddinglength;

      for(int j = 0; j < table.size(); j++) {
         printColumn();
         for(int i = 0; i < ((table.get(j)).record).size(); i++) {
            if((column_width[i] - table.get(j).record.get(i).toString().length()) % 2 == 0){
               left_paddinglength = (column_width[i] - table.get(j).record.get(i).toString().length()) / 2;
               right_paddinglength = column_width[i] - table.get(j).record.get(i).toString().length() - left_paddinglength;
            }
            else{
               left_paddinglength = (column_width[i] - table.get(j).record.get(i).toString().length() + 1) / 2;
               right_paddinglength = column_width[i] - table.get(j).record.get(i).toString().length() - left_paddinglength;
            }
            printSpace(left_paddinglength);
            System.out.print(table.get(j).record.get(i));
            printSpace(right_paddinglength);
            printColumn();
         }
         System.out.print("\n");
      }

   }

   // Print the table
   void printTable(){

      getColumnwidth();
      printFeatures();
      printRecord();
      printHeading();

   }

   // FILE

   // Read the table from the file
   void readTable(File file) throws IOException {

      BufferedReader br = null;
      FileReader fr = null;

      try{

        fr = new FileReader(file);
        br = new BufferedReader(fr);


        String sCurrentLine;

        while ((sCurrentLine = br.readLine()) != null) {
           System.out.println(sCurrentLine);
        }

      } catch (IOException e) {

        System.out.println("Problem reading from file.");
        throw e;

      }

   }

   // Write the table to the file
   void writeTable() throws IOException {

       try {
           //Whatever the file path is.
           File statText = new File(table_name+".txt");
           FileOutputStream is = new FileOutputStream(statText);
           OutputStreamWriter osw = new OutputStreamWriter(is);
           Writer w = new BufferedWriter(osw);

           for(int i = 0; i < features.size(); i++) {
              w.write(features.get(i));
              if((features.get(i)).equals(primary_key)){
                 w.write("*");
              }
              w.write(" ");
           }
           w.write("\n");

           for(int j = 0; j < table.size(); j ++){
              for(int i = 0; i < ((table.get(j)).record).size(); i++){
                 w.write(((table.get(j)).record).get(i)+" ");
              }
              w.write("\n");
           }
           w.close();

       } catch (IOException e) {
           System.out.println("Problem writing to the file.");
           throw e;
       }

   }

   public static void main(String[] args) {

      Table t = new Table("Student");
      t.setPrimarykey();
      Record r = new Record(4);
      t.insertRecord(r);
      Record e = new Record(4);
      t.insertRecord(e);
      t.printTable();

      try{t.writeTable();} catch(IOException a){} finally{

      File f = new File("Student.txt");
      try{t.readTable(f);} catch(IOException a){}

      }
      // try{t.writeTable()} catch(IOException e) finally{}


   }

}

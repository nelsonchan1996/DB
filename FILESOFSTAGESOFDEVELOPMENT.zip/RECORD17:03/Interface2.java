import java.util.Scanner;
import java.util.ArrayList;

class Interface{

   // An arraylist that stores each table of the database
   ArrayList<Database> interface;
   // The number of databases
   int num_of_database;

   // 2-space padding for printing
   final int padding = 2;

   void printMainmenu(){

      System.out.println("MAIN MENU: ");
      System.out.println("1. VIEW ALL");
      System.out.println("2. CREATE DATABASE");
      System.out.println("3. SELECT DATABASE");

   }

   void printDatabasemenu(){

      System.out.println("DATABASE MENU: ");
      System.out.println("1. VIEW DATABASE");
      System.out.println("2. DELETE DATABASE");
      System.out.println("3. CREATE TABLE");
      System.out.println("4. SELECT TABLE");
      System.out.println("5. BACK");

   }

   void printTablemenu(){

      System.out.print("TABLE MENU: ");
      System.out.println("1. VIEW DATABASE");
      System.out.println("2. DELETE TABLE");
      System.out.println("3. CREATE TABLE");
      System.out.println("4. SELECT TABLE");
      System.out.println("5. BACK");

   }

   void printRecordmenu(){

     System.out.print("RECORD MENU: ");
     System.out.println("1. VIEW RECORD");
     System.out.println("2. DELETE RECORD");
     System.out.println("3. UPDATE RECORD");
     System.out.println("4. BACK");

   }

   // PRINTING
   // get the maximum table name length
   void getDatabasenamelength(){

      max_databasenamelength = 0;

      for(int i = 0; i < database.size(); i++){
         if(max_databasenamelength < database.get(i).database_name.length()){
            max_databasenamelength = database.get(i).database_name.length();
         }
      }

   }

   // Print the heading
   void printHeading(){

      int headinglength = database_name.length() + (padding+1)*2;

      System.out.print(" ");

      for(int i = 0; i < headinglength - 1; i++) {
         System.out.print("-");
      }

      System.out.print("\n");

   }

   // Print the padding space
   void printSpace(int n){

      for(int i = 0; i < n; i++){
         System.out.print(" ");
      }

   }

   // Print column bar
   void printColumn(){

      System.out.print("|");

   }

   void printDatabaseNames(){

      int left_paddinglength;
      int right_paddinglength;

      for(int i = 0; i < interface.size(); i++){

         if((max_tablenamelength - interface.get(i).database_name.length()) % 2 == 0){
            left_paddinglength = right_paddinglength = (max_tablenamelength - interface.get(i).database_name.length()) / 2;
         }
         else{
            left_paddinglength = (max_tablenamelength - interface.get(i).database_name.length() + 1) / 2;
            right_paddinglength = max_tablenamelength - left_paddinglength;
         }

         printColumn();
         printSpace(padding+left_paddinglength);
         System.out.print(interface.get(i).database_name);
         printSpace(padding+right_paddinglength);
         printColumn();
         System.out.println();

      }

   }

   //Print a blank line
   void printBlankline(){

      printColumn();
      printSpace(padding);
      printSpace(max_databasenamelength);
      printSpace(padding);
      printColumn();
      System.out.print("\n");

   }


   //Print database
   void printDatabase(){

      getTablenamelength();
      printDatabasename();
      printHeading();
      printBlankline();
      printDatabaseNames();
      printBlankline();
      printHeading();

   }

   public static void main(String[] args) {

      Scanner scanner = new Scanner(System.in);
      int n = scanner.nextInt();

   }

 }
